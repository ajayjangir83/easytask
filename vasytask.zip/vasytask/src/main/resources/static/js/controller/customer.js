app.controller('customerCtrl', ['$scope', '$filter', '$http', '$window', '$location', '$timeout' ,
	function ($scope, $filter, $http, $window, $location, $timeout) {
	
	$scope.search = '';   
    
	var baseUrl = $location.protocol()+"://"+location.host+url;
	
		var link = baseUrl+'getAllCustomer';
		$http.get(link).success(function(data, status, headers, config) {
			$scope.getAllCustomers = data;
		}).error(function(data, status, headers, config) {
			$scope.getAllCustomers = "Response Fail";
		});
		
			
	$scope.setFlag = function() {
		$scope.errorAddress == 0;
		$scope.errorCustomerTitle = 0;
		$scope.errorEmail = 0;
		$scope.errorSubject = 0;
	}

	$scope.addresslist = [];
	$scope.addAddressRow = function() {
		
		if(!$scope.stateadd) {
			$scope.stateadd = " ";
		}
		if(!$scope.cityadd) {
			$scope.cityadd = " ";
		}
		if(!$scope.pincodeadd) {
			$scope.pincodeadd = " ";
		}
		
		if(!$scope.addressadd) {
			$scope.errorAddress = 1;
			$scope.msgAddress = "Please enter address!";
			document.getElementById("addressadd").focus();
		} else {
			$scope.addresslist.push({'address':$scope.addressadd, 'state':$scope.stateadd, 'city':$scope.cityadd, 'pincode':$scope.pincodeadd});
			document.getElementById('addressadd').value = '';
			document.getElementById('stateadd').value = '';
			document.getElementById('cityadd').value = '';
			document.getElementById("pincodeadd").value = '';
		}
	}
	
	$scope.removeAddressRow = function(item) {
		var index = -1;
		for(var i=0; i<$scope.addresslist.length; i++) {
			if($scope.addresslist[i] == item){
				index = i;
				break;
			}
		}
		if(index < 0) {
			$window.alert("Error while removing file...Please try again!");
			return;
		}
		$scope.addresslist.splice(index, 1);
	};
	
	
	
	$scope.addCustomer = function() {
		if(!$scope.mobileadd) {
			$scope.mobileadd = " ";
		}
				
		if(!$scope.customertitleadd) {			
			$scope.errorCustomerTitle = 1;
			$scope.msgCustomerTitle = "Please enter customer title";
			document.getElementById("customertitleadd").focus();
		} else if(!$scope.emailadd) {			
			$scope.errorEmail = 1;
			$scope.msgEmail = "Please enter customer email";
			document.getElementById("emailadd").focus();
		} else  {
			var c= 0;
			$scope.addrlist = [];
			$scope.statelist = [];
			$scope.citylist = [];
			$scope.pincodelist = [];
			angular.forEach($scope.addresslist,function(item) {
				$scope.addrlist.push(item.address);
				$scope.statelist.push(item.state);
				$scope.citylist.push(item.city);
				$scope.pincodelist.push(item.pincode);
				c = c + 1;
			});
			
			$scope.spin = 1;
				var link = baseUrl+ 'addCustomer?customertitle='+ $scope.customertitleadd+'&mobile='+$scope.mobileadd+'&email='+$scope.emailadd+'&addrlist='+$scope.addrlist+'&statelist='+$scope.statelist+'&citylist='+$scope.citylist+'&pincodelist='+$scope.pincodelist;
				$http.post(link).success(function(data, status, headers, config) {
					$scope.addcustomer = data;
					if($scope.addcustomer == "Success") {
        				$scope.spin = 0;
        				$scope.SubmitSuccess = 1;
        				$scope.msgSuccess = "Customer added successfully";
        				$timeout(function() {
        					$scope.SubmitSuccess = 0;
        					$window.location.href = adminurl + 'customer';
        				}, 3000);
        			} else {
        				$scope.spin = 0;
        				$scope.SubmitError = 1;
        				$scope.msgError = $scope.addcustomer;
        				$timeout(function() {
        					$scope.SubmitError = 0; 				
        				}, 5000);        				    				
        			}
				}).error(function(data,status,headers,config) {
					$scope.addcustomer = "Response Fail";
    				$scope.msgError = $scope.addcustomer;
				});
	}
	}
	
	$scope.editCourseFiles = function(id) {
		var paidnew = document.getElementById('paidedit');
				
		if (paidnew.checked == true){
			$scope.paid ="y";
		} else {
		    $scope.paid ="n";
		}
		if(!$scope.descriptionedit) {
			$scope.descriptionedit = " ";
			
		}
		var valuex = document.getElementById("valuex1").value;
		var valuey = document.getElementById("valuey1").value;
		var valuew = document.getElementById("valuew1").value;
		var valueh = document.getElementById("valueh1").value;
		
		if(valuex == ''){
			valuex = 0;
		}
		if(valuey == ''){
			valuey = 0;
		}
		if(valuew == ''){
			valuew = 0;
		}
		if(valueh == ''){
			valueh = 0;
		}
		
		if(!$scope.filetitleedit) {
			$scope.errorFileTitle = 1;
			$scope.msgFileTitle = "Please enter file title!";
			document.getElementById("filetitleedit").focus();
		} else if(!$scope.subjectedit) {
			$scope.errorSubject = 1;
			$scope.msgSubject = "Please select subject name!";
			document.getElementById("subjectedit").focus();
		} else if(videofileedit.files[0]==undefined || videofileedit.files[0]=="") {
			document.getElementById("videofileedit").focus();
			$scope.errorCourseFile = 1;
			$scope.msgCourseFile = "Please select video file";
			$timeout(function(){
				$scope.errorCourseFile = 0;
			}, 2000);
		} else {
			$scope.spin = 1;
			var link = baseUrl+'editCourseFiles?courseid='+id+'&filetitle='+$scope.filetitleedit+'&paid='+$scope.paid+'&valuex='+valuex+'&valuey='+valuey+'&valuew='+valuew+'&valueh='+valueh+'&description='+$scope.descriptionedit+'&subject='+$scope.subjectedit;						
			
    		var formData = new FormData();
				formData.append("videoFile",videofileedit.files[0]);
				formData.append("pdfFile",pdffileedit.files[0]);
				formData.append("posterFile",posterfileedit.files[0]);
				$http({method: 'POST', url: link, headers: {'Content-Type': undefined}, data: formData, transformRequest: function(data, headersGetterFunction) { return data; }}).success(function(data, status, headers, config) {
    			$scope.editcoursefiles = data;
    			
    			if($scope.editcoursefiles == "File Uploaded Successfully") {
        				$scope.spin = 0;
        				$scope.SubmitSuccess = 1;
        				$scope.msgSuccess = "Course Files updated successfully";
        				$scope.getCourseDetail(id); 				
        				$timeout(function() {
        					$scope.SubmitSuccess = 0;
        				}, 2500);
        			} else {
        				$scope.spin = 0;
        				$scope.SubmitError = 1;
        				$scope.msgError = $scope.editcoursefiles;
        				$timeout(function() {
        					$scope.SubmitError = 0; 				
        				}, 5000);        				    				
        			}    				
    			}).error(function(data, status, headers, config) {
    				$scope.editcoursefiles = "Response Fail";
    				
    				$scope.msgError = $scope.editcoursefiles;
    			
    			});    			
			
		}

	}
	
	$scope.viewCourseFile = function(vid) {
		var link = baseUrl+'getVideoFileDetailsById?cid='+vid;
		$http.get(link).success(function(data, status, headers, config) {
			$scope.getVideoFileDetails = data;
		}).error(function(data, status, headers, config) {
			$scope.getVideoFileDetails = "Response Fail";
		});
	}
	
	$scope.getCustomerDetail = function(id) {
		var link = baseUrl+'getCustomerById?id='+id;
		$http.get(link).success(function(data, status, headers, config) {
			$scope.getCustomerById = data;
			$scope.customerid=$scope.getCustomerById.customerId;
			$scope.customertitleedit=$scope.getCustomerById.name;
			$scope.mobileedit = $scope.getCustomerById.mobile;
			$scope.emailedit = $scope.getCustomerById.email;
			var link = baseUrl+'getCustomerAddressById?id='+id;
			$http.get(link).success(function(data, status, headers, config) {
				$scope.addresslist1 = data;
			}).error(function(data, status, headers, config) {
				$scope.addresslist1 = "Response Fail";
			});
		}).error(function(data, status, headers, config) {
			$scope.getCustomerById = "Response Fail";
		});
	}
	
	$scope.checkAll = function() {
		if ($scope.selectedAll) {
			$scope.selectedAll = false;
		}
		else {
            $scope.selectedAll = true;
        }
		angular.forEach($scope.getCourseFiles, function (item) {
			item.selected = $scope.selectedAll;
		});
	}
	
	
	$scope.checkRecordSelectForDelete = function() {
		$scope.d = 0;				
		angular.forEach($scope.getCourseFiles, function(item) {
			if (item.selected) {
				$scope.d = $scope.d + 1;								
			}			
		});		
	}
	
	$scope.deleteCourseFiles = function() {
		angular.forEach($scope.getCourseFiles, function(item) {
			if (item.selected) {
				var link = baseUrl+'deleteCourseFiles?cid='+item.courseId;
				$http['delete'](link).success(function(data, status, headers, config) {
					$scope.deletefiles = data;
					var link = baseUrl+'getAllCourseFiles';
						$http.get(link).success(function(data, status, headers, config) {
							$scope.getCourseFiles = data;
						}).error(function(data, status, headers, config) {
							$scope.getCourseFiles = "Response Fail";
						});
				}).error(function(data, status, headers, config) {
					$scope.deletefiles = "Response Fail";
				});
			}
		});
		$window.location.href = adminurl+'manage_video';
	}
	
	$scope.deleteCourseFile = function(id,videopath,pdfpath) {
		
		var isConfirmed = confirm("Are you sure to delete this record ?");
	      if(isConfirmed){
	        var link = baseUrl+'deleteCourseFile?cfid='+id+'&videopath='+videopath+'&pdfpath='+pdfpath;
			$http['delete'](link).success(function(data, status, headers, config) {
				$scope.deletefile = data;
				$scope.getCourseDetail($scope.courseId);
			}).error(function(data, status, headers, config) {
				$scope.deletefile = "Response Fail";
			});
	      }
	      /*else{
	        return false;
	      }*/
		
			
	}
	
}]);