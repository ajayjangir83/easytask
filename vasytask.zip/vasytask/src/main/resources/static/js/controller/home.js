app.controller('homeCtrl', ['$scope', '$filter', '$http', '$window', '$location', '$timeout' ,
	function ($scope, $filter, $http, $window, $location, $timeout) {
	       
	var baseUrl = $location.protocol()+"://"+location.host+url;
	
	var link = baseUrl+'getAllTeachersFullDetails';
	$http.get(link).success(function(data, status, headers, config) {
		$scope.getTeachers = data;
	}).error(function(data, status, headers, config) {
		$scope.getTeachers = "Response Fail";
	});
	
	var link = baseUrl+'getAllStudentsFullDetails';
	$http.get(link).success(function(data, status, headers, config) {
		$scope.getUsers = data;
	}).error(function(data, status, headers, config) {
		$scope.getUsers = "Response Fail";
	});
	
	var link = baseUrl+'getAllCountForAdmin';
	$http.get(link).success(function(data, status, headers, config) {
		$scope.getAllCounts = data;
	}).error(function(data, status, headers, config) {
		$scope.getAllCounts = "Response Fail";
	});
	
	
	
	
	var link = baseUrl+'getTeacherAssignedCourseCount';
	$http.get(link).success(function(data, status, headers, config) {
		$scope.getTeacherCourseCounts = data;
	}).error(function(data, status, headers, config) {
		$scope.getTeacherCourseCounts = "Response Fail";
	});
	
	
	
	$scope.setVideo = function() {
		var src = $scope.video;
    	document.getElementById('div_video').innerHTML = '<video controls id="video_ctrl" style="height: 160px; width: 220px;"><source src="'+src+'" type="video/mp4"></video>';
	}
	
	
	var link = baseUrl+'getAboutUsContent';
	$http.get(link).success(function(data, status, headers, config) {
		$scope.getAboutUsContentDetails = data;
		
		$scope.id = $scope.getAboutUsContentDetails.aboutId;
		$scope.video = $scope.getAboutUsContentDetails.videoPath;
		$scope.oldimage = $scope.getAboutUsContentDetails.aboutPoster;
		$scope.content = $scope.getAboutUsContentDetails.content;
		
	}).error(function(data, status, headers, config) {
		$scope.getAboutUsContentDetails = "Response Fail";
	});
	
	$scope.searchStudent = function() {
		var search = $scope.search;
		if(!search){
			var link = baseUrl+'getAllStudentsFullDetails';
			$http.get(link).success(function(data, status, headers, config) {
				$scope.getUsers = data;
			}).error(function(data, status, headers, config) {
				$scope.getUsers = "Response Fail";
			});
		} else {
			var link = baseUrl+'searchStudent?keyword='+search;
			$http.get(link).success(function(data, status, headers, config) {
				$scope.getUsers = data;
			}).error(function(data, status, headers, config) {
				$scope.getUsers = "Response Fail";
			});
		}
		
	}
	
	$scope.searchTeacher = function() {
		var search = $scope.search1;
		if(!search){
			var link = baseUrl+'getAllTeachersFullDetails';
			$http.get(link).success(function(data, status, headers, config) {
				$scope.getTeachers = data;
			}).error(function(data, status, headers, config) {
				$scope.getTeachers = "Response Fail";
			});
		} else {
			var link = baseUrl+'searchTeacher?keyword='+search;
			$http.get(link).success(function(data, status, headers, config) {
				$scope.getTeachers = data;
			}).error(function(data, status, headers, config) {
				$scope.getTeachers = "Response Fail";
			});
		}
		
	}
	
	
	$scope.updateAboutusContent = function() {
		var id = 1;
		var valuex = document.getElementById("valuex1").value;
		var valuey = document.getElementById("valuey1").value;
		var valuew = document.getElementById("valuew1").value;
		var valueh = document.getElementById("valueh1").value;
		
		if(valuex == ''){
			valuex = 0;
		}
		if(valuey == ''){
			valuey = 0;
		}
		if(valuew == ''){
			valuew = 0;
		}
		if(valueh == ''){
			valueh = 0;
		}
		
		if(!$scope.content) {
			$scope.content = "";
		}
				
		if(videofile.files[0]==undefined || videofile.files[0]=="") {
			document.getElementById("videofile").focus();
			$scope.errorCourseFile = 1;
			$scope.msgCourseFile = "Please select video file";
			$timeout(function(){
				$scope.errorCourseFile = 0;
			}, 2000);
		} else {
			$scope.spin = 1;
			var link = baseUrl+'updateAboutContent?id='+id+'&content='+$scope.content+'&valuex='+valuex+'&valuey='+valuey+'&valuew='+valuew+'&valueh='+valueh+'&oldimage='+$scope.oldimage+'&oldvideo='+$scope.video;						
			
    		var formData = new FormData();
				formData.append("videoFile",videofile.files[0]);
				formData.append("posterFile",posterfile.files[0]);
				$http({method: 'POST', url: link, headers: {'Content-Type': undefined}, data: formData, transformRequest: function(data, headersGetterFunction) { return data; }}).success(function(data, status, headers, config) {
    			$scope.editcoursefiles = data;
    			
    			if($scope.editcoursefiles == "File Uploaded Successfully") {
        				$scope.spin = 0;
        				$scope.SubmitSuccess = 1;
        				$scope.msgSuccess = "About Us Content updated successfully";
        				$timeout(function() {
        					$scope.SubmitSuccess = 0;
        					$window.location.href = adminurl + 'home';
        				}, 2500);
        			} else {
        				$scope.spin = 0;
        				$scope.SubmitError = 1;
        				$scope.msgError = $scope.editcoursefiles;
        				$timeout(function() {
        					$scope.SubmitError = 0; 				
        				}, 5000);        				    				
        			}    				
    			}).error(function(data, status, headers, config) {
    				$scope.editcoursefiles = "Response Fail";
    				
    				$scope.msgError = $scope.editcoursefiles;
    			
    			});    			
			
		}

	}
	
	
}]);