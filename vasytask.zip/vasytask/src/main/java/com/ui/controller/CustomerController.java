package com.ui.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.ui.impl.CustomerImpl;
import com.ui.model.Customer;
import com.ui.model.CustomerAddress;

@RestController
public class CustomerController {

	@Autowired
	CustomerImpl dao;
	
	@RequestMapping(value = "addCustomer", method = RequestMethod.POST)
	public String addCustomer(String customertitle, String mobile, String email, String addrlist[], String statelist[], String citylist[], String pincodelist[],HttpServletRequest request, HttpSession session) {
		String result = null;
		//int id = Integer.parseInt(session.getAttribute("useridadmin").toString());
		
		String s = "y";
				
		Customer c = new Customer();
		c.setStatus(s);
		c.setName(customertitle);
		c.setMobile(mobile);
		c.setEmail(email);
		
		result = dao.addCustomer(c);
		
		if(result=="Success") {
						
			for (int i = 0; i < addrlist.length; i++) {
			  
				//System.out.println("**************************-------------"+addrlist[0]);
				
				CustomerAddress ca = new CustomerAddress();
				ca.setCustomerId(dao.getLastCustomerId());
				ca.setAddress(addrlist[i]);
				ca.setState(statelist[i]);
				ca.setCity(citylist[i]);
				ca.setPincode(pincodelist[i]);
				
				result = dao.addCustomerAddress(ca);
				
			}
		}
		return result;
	}
	
	
	@RequestMapping(value = "getAllCustomer",method = RequestMethod.GET)
	public List<Customer> getAllCustomer(HttpSession session){
		return dao.getAllCustomer(session);
	}
	
	@RequestMapping(value = "getCustomerById",method = RequestMethod.GET)
	public Customer getCustomerById(int id) {
		return dao.getCustomerById(id);
	}
	
	@RequestMapping(value = "getCustomerAddressById",method = RequestMethod.GET)
	public List<CustomerAddress> getCustomerAddressById(int id){
		return dao.getCustomerAddressById(id);
	}
	
	
	
	

} //end
