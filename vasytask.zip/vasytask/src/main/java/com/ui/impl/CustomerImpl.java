package com.ui.impl;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;


import com.ui.model.Customer;
import com.ui.model.CustomerAddress;

@Repository
public class CustomerImpl {
	
	
	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	public String addCustomer(Customer c) {
		String updateQuery = "insert into customer (name, mobile, email, status) values (?,?,?,?)";
		jdbcTemplate.update(updateQuery,c.getName(),c.getMobile(),c.getEmail(),c.getStatus());
		return "Success";
	}
	
	public String addCustomerAddress(CustomerAddress ca) {
		String updateQuery = "insert into customer_address (customer_id, address, state, city, pincode) values (?,?,?,?,?)";
		jdbcTemplate.update(updateQuery,ca.getCustomerId(),ca.getAddress(),ca.getState(),ca.getCity(),ca.getPincode());
		return "Success";
	}
	
	public int getLastCustomerId() {
		String Query = "SELECT customer_id FROM customer order BY customer_id desc limit 0,1";
		return jdbcTemplate.queryForObject(Query, Integer.class);
	}
	
	
	public List<Customer> getAllCustomer(HttpSession session){
		
		String sql = "SELECT customer_id, name, mobile, email FROM customer where status='y' order by name";
		
        return jdbcTemplate.query(
                sql,
                (rs, rowNum) ->
                        new Customer(
                                rs.getInt("customer_id"),
                                rs.getString("name"),
                                rs.getString("mobile"),
                                rs.getString("email")
                        )
        );
	}
	
	public List<CustomerAddress> getCustomerAddressById(int id){
		
		String sql = "SELECT customer_address_id,customer_id, address, state, city, pincode FROM customer_address where customer_id=? order by address";
               
        return jdbcTemplate.query(
        		sql, new Object[]{id},
                (rs, rowNum) ->
                new CustomerAddress(
                		rs.getInt("customer_address_id"),
                        rs.getInt("customer_id"),
                        rs.getString("address"),
                        rs.getString("state"),
                        rs.getString("city"),
                        rs.getString("pincode")
                ));
	}
	
	public Customer getCustomerById(int id) {
		String query = "SELECT customer_id, name, mobile, email FROM customer where customer_id=?";
		return jdbcTemplate.queryForObject(query, new Object[]{id}, (rs, rowNum) ->new 
				Customer( rs.getInt("customer_id"),
                rs.getString("name"),
                rs.getString("mobile"),
                rs.getString("email")
        ));
	}

}
