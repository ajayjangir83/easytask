package com.ui.api.controller;


import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;

import org.springframework.web.bind.annotation.RequestMapping;



@Controller
public class MainController {
	
	@RequestMapping("/home")
	public String homePage( HttpSession session) {
		return "home";
	}
	
	@RequestMapping("/customer")
	public String customer( HttpSession session) {
		return "/customer";
	}
			
	@RequestMapping("/")
	public String login(HttpSession session) {
		return "home";
	}
}
