package com.ui.model;

public class CustomerAddress {
	
	private int customerAddressId;
	private int customerId;
	private String address;
	private String state;
	private String city;
	private String pincode;
	private String createdDate;
	public int getCustomerAddressId() {
		return customerAddressId;
	}
	public void setCustomerAddressId(int customerAddressId) {
		this.customerAddressId = customerAddressId;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getPincode() {
		return pincode;
	}
	public void setPincode(String pincode) {
		this.pincode = pincode;
	}
	public String getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}
	public CustomerAddress() {
		super();
		// TODO Auto-generated constructor stub
	}
	public int getCustomerId() {
		return customerId;
	}
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	public CustomerAddress(int customerAddressId, int customerId, String address, String state, String city,
			String pincode) {
		super();
		this.customerAddressId = customerAddressId;
		this.customerId = customerId;
		this.address = address;
		this.state = state;
		this.city = city;
		this.pincode = pincode;
	}
	
	

}
